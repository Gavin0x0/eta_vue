<template>
  <div class="home">
    <h3>优秀奖项展示</h3>
    <el-carousel :interval="4000" type="card" height="200px">
      <el-carousel-item v-for="item in 6" :key="item">
        <h3 class="medium">{{ item }}</h3>
      </el-carousel-item>
    </el-carousel>
    
    <el-row :gutter="20">
      <el-col :span="8">
        <el-card class="info-card" shadow="always">
          <div slot="header" class="clearfix">
            <span>公告</span>
            <el-button style="float: right; padding: 3px 0" type="text"
              >编辑</el-button
            >
          </div>
          <div v-for="o in 4" :key="o" class="text item">
            {{ "公告 " + o }}
          </div>
        </el-card>
      </el-col>
      <el-col :span="16">
        <el-card class="info-card" shadow="always">
          <NumberCounter :stuNum="stuItemNum" :teaNum="teaItemNum" :totalNum="totalItemNum" />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { initHome } from "../api";
import NumberCounter from "../components/NumberCounter.vue";
import { mapGetters } from "vuex";
export default {
  name: "Home",
  components: {NumberCounter},
  methods: {},
  computed: {
    ...mapGetters([
      "stuItemNum",
      "teaItemNum",
      "totalItemNum",
    ]),
  },
};
</script>

<style>
.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
  text-align: center;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}
</style>
