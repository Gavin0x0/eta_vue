import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import LoginScreen from '../screens/LoginScreen.vue'
import MainScreen from '../screens/MainScreen.vue'
import Upload from '../views/Upload'
import Mine from '../views/Mine'
import Password from '../views/Password'
import QueryStu from '../views/QueryStu'
import QueryTea from '../views/QueryTea'
import Review from '../views/Review'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'LoginScreen',
    component: LoginScreen
  },
  {
    path: '/eta',
    name: 'MainScreen',
    component: MainScreen,
    children: [
      {
        // 当 /eta/home 匹配成功，
        // Home 会被渲染在 MainScreen 的 <router-view> 中
        path: 'home',
        component: Home
      },
      {
        path: 'upload',
        component: Upload
      },
      {
        path: 'mine',
        component: Mine
      },
      {
        path: 'password',
        component: Password
      },
      {
        path: 'query-stu',
        component: QueryStu
      },
      {
        path: 'query-tea',
        component: QueryTea
      },
      {
        path: 'review',
        component: Review
      },

      {
        path: 'about',
        component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
      },
    ]
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    // 使用时导入，类似懒加载
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
